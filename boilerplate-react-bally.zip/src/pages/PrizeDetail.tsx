import React from "react";

const PrizeDetail = () => {
  return <div>PrizeDetail</div>;
};

export default PrizeDetail;
