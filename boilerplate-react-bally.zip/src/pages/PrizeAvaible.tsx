import React from "react";

const PrizeAvaible = () => {
  return <div>PrizeAvaible</div>;
};

export default PrizeAvaible;
