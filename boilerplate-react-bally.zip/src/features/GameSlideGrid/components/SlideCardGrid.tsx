import React from "react";

const SlideCardGrid = () => {
  return (
    <div className="slideCard flex flex-col">
      <div className="title min-h-[30px] flex flex-col items-center justify-center">
        <h1>USTED PEUDE CANJEAR SU REGALO</h1>
      </div>
      <div className="prizes"></div>
      <div className="points min-h-[30px] flex flex-col items-center justify-center gap-2">
        <div className="flex flex-row gap-2">
          <div>
            <p>USTED TIENE:</p>
          </div>
          <div>
            <p>0000 PTS</p>
          </div>
        </div>
        <div>
          <div className="range"></div>
        </div>
      </div>
    </div>
  );
};

export default SlideCardGrid;
