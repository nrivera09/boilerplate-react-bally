export type DimensionPreset = {
  label: string;
  width: number;
  height: number;
};
