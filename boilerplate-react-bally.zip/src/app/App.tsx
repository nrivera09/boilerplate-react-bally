import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { IResponsivePresets } from "../features/GameSlideGrid/interfaces/IDimensionPreset";
import Router from "./Router";

function App() {
  const isLocal = window.location.hostname === "localhost";
  const [selectedSize, setSelectedSize] = useState(IResponsivePresets[0]);
  const [showSelector, setShowSelector] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Renderizamos dentro del iframe cuando cambian las dimensiones
  useEffect(() => {
    if (isLocal && iframeRef.current) {
      const iframe = iframeRef.current;
      const doc = iframe.contentDocument || iframe.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write("<div id='app'></div>");
        doc.close();

        // Creamos raíz independiente dentro del iframe
        const mountNode = doc.getElementById("app");
        if (mountNode) {
          createRoot(mountNode).render(<Router />);
        }
      }
    }
  }, [selectedSize, isLocal]);

  if (!isLocal) return <Router />;

  // Calculamos dimensiones
  const iframeWidth =
    selectedSize.label === "Full View" ? "100%" : selectedSize.width;
  const iframeHeight =
    selectedSize.label === "Full View" ? "100lvh" : selectedSize.height;

  return (
    <div className="relative w-full h-screen flex items-center justify-center overflow-hidden bg-gray-200">
      <button
        onClick={() => setShowSelector(!showSelector)}
        className="fixed z-50 bottom-4 right-4 bg-gray-800 text-white p-3 rounded-full shadow-xl hover:bg-gray-700 transition"
      >
        🎰
      </button>

      {/* Selector de resolución */}
      {showSelector && (
        <div className="fixed z-50 bottom-20 right-4 bg-white rounded-lg shadow-md p-4 border w-72 animate-fade-in">
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Selecciona tu Iview:
          </label>
          <select
            className="w-full border rounded px-3 py-2 text-sm"
            value={selectedSize.label}
            onChange={(e) => {
              const preset = IResponsivePresets.find(
                (p) => p.label === e.target.value
              );
              if (preset) setSelectedSize(preset);
              setShowSelector(false);
            }}
          >
            {IResponsivePresets.map((preset) => (
              <option key={preset.label} value={preset.label}>
                {preset.label}
              </option>
            ))}
          </select>
        </div>
      )}

      <iframe
        key={selectedSize.label}
        ref={iframeRef}
        className="border-none mx-auto rounded-md shadow-sm"
        style={{
          width: iframeWidth,
          height: iframeHeight,
          display: "block",
          background: "white",
        }}
        title="GameSlide Preview"
      />
    </div>
  );
}

export default App;
